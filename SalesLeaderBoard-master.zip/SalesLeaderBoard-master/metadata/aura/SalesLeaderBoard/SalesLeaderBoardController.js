({
	getData: function(component, event, helper) {
		helper.setdashboard(component);
	}
})