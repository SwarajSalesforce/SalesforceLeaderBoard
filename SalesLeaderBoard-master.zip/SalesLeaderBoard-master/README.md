# SalesLeaderBoard
SalesLeaderBoard Application is a lightning based application which demonstrates the ability to open and close a modal for SLDS
